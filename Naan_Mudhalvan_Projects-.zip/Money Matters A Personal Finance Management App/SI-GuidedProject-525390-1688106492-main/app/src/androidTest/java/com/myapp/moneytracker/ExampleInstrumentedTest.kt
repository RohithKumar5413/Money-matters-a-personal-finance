version https://git-lfs.github.com/spec/v1
oid sha256:c50efa2aa7f2a0eddca01a521975a693f94ca7c967e8d10266f677b63e9dd7d9
size 487
